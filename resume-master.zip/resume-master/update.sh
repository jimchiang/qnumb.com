wget https://raw.githubusercontent.com/ericmjl/website/master/templates/layout.html -O templates/layout.html.j2
