# resume-template
A repository storing the HTML file that I used on my personal website's resume page, as a template.
